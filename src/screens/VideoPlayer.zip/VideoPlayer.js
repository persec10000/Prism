import React, {
    Component
} from 'react';

import {
    AppRegistry,
    StyleSheet,
    Text,
    TouchableOpacity,
    ToastAndroid,
    AlertIOS,BackHandler,
    View, Dimensions, Image, NetInfo, PanResponder,
    AsyncStorage
} from 'react-native';
import {
    Container,
    Header,
    Title,
    Content,
    Button,
    Card,
    CardItem,
    Thumbnail,
    Left,
    Body,
    Right,
    IconNB,
    Label,
    Input,
    Form, FooterTab, Footer,
    Row, CheckBox, Col
} from "native-base";
import { Colors, Fonts, Images } from '../themes';
var width = Dimensions.get('window').width; //full width
var height = Dimensions.get('window').height; //full height
import Video from 'react-native-video';
import RNFetchBlob from 'react-native-fetch-blob'
import api from '../api'
import UserInactivity from 'react-native-user-inactivity';
var UserID;
var UserEmailID,url;
export default class LocalVideo extends React.Component {
    constructor(props) {
        super(props);
        console.log("video")
        this.state = {
            rate: 1,
            volume: 1,
            muted: false,
            resizeMode: 'contain',
            duration: 0.0,
            currentTime: 0.0,
            paused: true,
            show:false
        };
        this.checkNet();
    }
    //check internet start//
    checkNet = () => {
        NetInfo.isConnected.addEventListener('connectionChange', this.handleConnectionChange);
        NetInfo.isConnected.fetch().done(
            (isConnected) => { this.setState({ status: isConnected }); }
        );
    }

    componentWillUnmount() {
        NetInfo.isConnected.removeEventListener('connectionChange', this.handleConnectionChange);
        this.back_componentWillUnmount()
    }
    handleConnectionChange = (isConnected) => {
        this.setState({ status: isConnected });
        console.log(`is connected: ${this.state.status}`);
        if (this.state.status == false) {
            Platform.select({
                ios: () => { AlertIOS.alert('Connect to the Internet'); },
                android: () => { ToastAndroid.show('Connect to the Internet', ToastAndroid.SHORT); }
            })();
            this.props.navigation.navigate("Login")
        }
    }
    //check internet end//
    async componentWillMount () {
        UserID = await AsyncStorage.getItem('ID');
        UserEmailID = await AsyncStorage.getItem('EmailID');
        { this.setState({ paused: !this.state.paused }) }
        this.openFile();
        this.back_componentDidMount()
    }

    async openFile() {
        var params = this.props.navigation.state.params;
        console.log(params)
        // let dirs = RNFetchBlob.fs.dirs
        // console.log(dirs)
        //     RNFetchBlob.config({
        //     fileCache : true,
        //     appendExt : params.DocumentType,
        //     path : dirs.DocumentDir + params.DocumentName
        // })
        // // .fetch('GET', api.View_URL+"?FileName="+params.DocumentGuid+"&Email="+UserEmailID+"&UserId="+UserID, {
        // // })
        // .fetch('GET', "http://vdrapi.yourdataprocessor.com/VDR/Document/view?FileName="+params.DocumentGuid+"&Email="+UserEmailID+"&UserId="+UserID, {
        // })
        // .then((res) => {
        //     this.setState({path: res.data, show :true});
        //     console.log('The file saved to ', res.path())
        //     console.log('The file saved to ', this.state.path)
        // })
        this.setState({ show :true});
        url = "http://vdrapi.yourdataprocessor.com/VDR/Document/view?FileName="+params.DocumentGuid+"&Email="+UserEmailID+"&UserId="+UserID;
        console.log( url);
    }

    componentDidMount = () => {
        { this.setState({ paused: !this.state.paused }) }
        this.back_componentDidMount()
    }

    video: Video;

    onLoad = (data) => {
        this.setState({ duration: data.duration });
    };

    onProgress = (data) => {
        this.setState({ currentTime: data.currentTime });
    };

    onEnd = () => {
        this.setState({ paused: true })
        this.video.seek(0)
    };

    onAudioBecomingNoisy = () => {
        this.setState({ paused: true })
    };

    onAudioFocusChanged = (event: { hasAudioFocus: boolean }) => {
        this.setState({ paused: !event.hasAudioFocus })
    };

    getCurrentTimePercentage() {
        if (this.state.currentTime > 0) {
            return parseFloat(this.state.currentTime) / parseFloat(this.state.duration);
        }
        return 0;
    };

    renderRateControl(rate) {
        const isSelected = (this.state.rate === rate);

        return (
            <TouchableOpacity onPress={() => { this.setState({ rate }) }}>
                <Text style={[styles.controlOption, { fontWeight: isSelected ? 'bold' : 'normal' }]}>
                    {rate}x
          </Text>
            </TouchableOpacity>
        );
    }

    renderResizeModeControl(resizeMode) {
        const isSelected = (this.state.resizeMode === resizeMode);

        return (
            <TouchableOpacity onPress={() => { this.setState({ resizeMode }) }}>
                <Text style={[styles.controlOption, { fontWeight: isSelected ? 'bold' : 'normal' }]}>
                    {resizeMode}
                </Text>
            </TouchableOpacity>
        )
    }

    renderVolumeControl(volume) {
        const isSelected = (this.state.volume === volume);

        return (
            <TouchableOpacity onPress={() => { this.setState({ volume }) }}>
                <Text style={[styles.controlOption, { fontWeight: isSelected ? 'bold' : 'normal' }]}>
                    {volume * 100}%
          </Text>
            </TouchableOpacity>
        )
    }

    backPress() {
        { this.setState({ paused: !this.state.paused }) }
        { this.props.navigation.goBack() }

    }


      //exit app start//
      onButtonPress = () => {
        BackHandler.removeEventListener('hardwareBackPress', this.handleBackButton);
        // then navigate
        navigate('NewScreen');
      }
      
      handleBackButton = () => {
        this.props.navigation.navigate('MyDownloads')
        return true;
      } 
      
      back_componentDidMount() {
        BackHandler.addEventListener('hardwareBackPress', this.handleBackButton);
      }
      
      back_componentWillUnmount() {
        BackHandler.removeEventListener('hardwareBackPress', this.handleBackButton);
      }
    //exit app end//  
    render() {
        const flexCompleted = this.getCurrentTimePercentage() * 100;
        const flexRemaining = (1 - this.getCurrentTimePercentage()) * 100;

        return (
            <UserInactivity
                timeForInactivity={300000}
                checkInterval={1000}
                onInactivity={()=> this.props.navigation.navigate("Login")}
            >
            <View style={styles.container}>
                <Header
                    hasTabs
                    style={{ backgroundColor: "#285A7F", justifyContent: 'center' }}
                    androidStatusBarColor="#053A59"
                    iosBarStyle="light-content">
                    <View style={{ width: '100%', flexDirection: "row", alignItems: 'center', justifyContent: 'center' }}>
                        <TouchableOpacity
                            onPress={() => this.props.navigation.goBack()}
                            style={{ position: 'absolute', left: 5 }}>
                            <Image
                                source={Images.back}
                                style={{ width: 35, height: 35, }}
                            />
                        </TouchableOpacity>
                        <Text style={{ fontWeight: 'bold', color: "#FFF", fontSize: 20, position: 'absolute' }}>
                            Video</Text>
                    </View>
                </Header>
                {this.state.show  &&
                <View style={styles.container}>
              
                    <TouchableOpacity
                        style={styles.fullScreen}

                    >
                        <Video
                            ref={(ref: Video) => { this.video = ref }}
                            source={{ uri: url, type: 'mp4' }}
                            style={styles.fullScreen}
                            rate={this.state.rate}
                            paused={this.state.paused}
                            volume={this.state.volume}
                            muted={this.state.muted}
                            resizeMode={this.state.resizeMode}
                            onLoad={this.onLoad}
                            onProgress={this.onProgress}
                            onEnd={this.onEnd}
                            onAudioBecomingNoisy={this.onAudioBecomingNoisy}
                            onAudioFocusChanged={this.onAudioFocusChanged}
                            repeat={false}
                        />
                    </TouchableOpacity>
               
                    <View style={styles.controls}>
                        <View style={styles.generalControls}>
                            <View style={styles.rateControl}>
                                {this.renderRateControl(0.25)}
                                {this.renderRateControl(0.5)}
                                {this.renderRateControl(1.0)}
                                {this.renderRateControl(1.5)}
                                {this.renderRateControl(2.0)}
                            </View>

                            <View style={styles.volumeControl}>
                                {this.renderVolumeControl(0.5)}
                                {this.renderVolumeControl(1)}
                                {this.renderVolumeControl(1.5)}
                            </View>

                            <View style={styles.resizeModeControl}>
                                {this.renderResizeModeControl('cover')}
                                {this.renderResizeModeControl('contain')}
                                {this.renderResizeModeControl('stretch')}
                            </View>
                        </View>
                
                        <View style={styles.trackingControls}>
                            <View style={styles.progress}>
                                <View style={[styles.innerProgressCompleted, { flex: flexCompleted }]} />
                                <View style={[styles.innerProgressRemaining, { flex: flexRemaining }]} />
                            </View>
                        </View>
                    </View>
               
                </View> }
            </View>
            </UserInactivity>
        );
    }
}


const styles = StyleSheet.create({
    container: {
        backgroundColor: 'black',
        height: height,
        width: width
    },
    fullScreen: {
        position: 'absolute',
        top: 0,
        left: 0,
        bottom: 0,
        right: 0,
    },
    controls: {
        backgroundColor: 'transparent',
        borderRadius: 5,
        position: 'absolute',
        bottom: 20,
        left: 20,
        right: 20,
    },
    progress: {
        flex: 1,
        flexDirection: 'row',
        borderRadius: 3,
        overflow: 'hidden',
    },
    innerProgressCompleted: {
        height: 20,
        backgroundColor: '#cccccc',
    },
    innerProgressRemaining: {
        height: 20,
        backgroundColor: '#2C2C2C',
    },
    generalControls: {
        flex: 1,
        flexDirection: 'row',
        borderRadius: 4,
        overflow: 'hidden',
        paddingBottom: 10,
    },
    rateControl: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
    },
    volumeControl: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
    },
    resizeModeControl: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    controlOption: {
        alignSelf: 'center',
        fontSize: 11,
        color: 'white',
        paddingLeft: 2,
        paddingRight: 2,
        lineHeight: 12,
    },
});